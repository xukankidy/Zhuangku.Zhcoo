﻿'use strict';
$(function () {
    zk.initialize();
});