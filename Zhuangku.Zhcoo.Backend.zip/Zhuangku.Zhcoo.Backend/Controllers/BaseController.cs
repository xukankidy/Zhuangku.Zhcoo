﻿using System.Web.Mvc;

namespace Zhuangku.Zhcoo.Backend.Controllers
{
    /// <summary>
    /// 控制器基类
    /// </summary>
    public class BaseController : Controller
    {
    }
}